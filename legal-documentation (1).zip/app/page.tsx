import Link from 'next/link'
import { LEGAL_DOCS, SERVICE } from '@/lib/legal-data'

export default function Page() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 py-16 text-foreground">
      <div className="w-full max-w-xl">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <span className="text-lg font-bold">P</span>
          </div>
          <div>
            <p className="font-semibold leading-tight">{SERVICE.name}</p>
            <p className="text-sm text-muted-foreground">Юридические документы</p>
          </div>
        </div>

        <h1 className="mt-8 text-balance text-2xl font-bold sm:text-3xl">
          Правовые документы мессенджера Pulse
        </h1>
        <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
          Pulse — личный некоммерческий проект для друзей и родственников. Ниже собраны правила
          использования, политика конфиденциальности и согласие на обработку данных.
        </p>

        <ul className="mt-8 flex flex-col gap-3">
          {LEGAL_DOCS.map((doc) => (
            <li key={doc.slug}>
              <Link
                href={`/legal/${doc.slug}`}
                className="flex items-center justify-between rounded-xl border border-border p-4 transition-colors hover:bg-secondary/60"
              >
                <span>
                  <span className="block font-medium">{doc.short}</span>
                  <span className="block text-sm text-muted-foreground">
                    {doc.title.split('(')[0].trim()}
                  </span>
                </span>
                <span aria-hidden className="text-muted-foreground">
                  →
                </span>
              </Link>
            </li>
          ))}
        </ul>

        <Link
          href="/legal"
          className="mt-6 inline-block text-sm text-primary underline underline-offset-4"
        >
          Открыть общий раздел документов
        </Link>
      </div>
    </main>
  )
}
