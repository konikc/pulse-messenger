import type { Metadata } from 'next'
import Link from 'next/link'
import { LEGAL_DOCS, LAST_UPDATED, SERVICE } from '@/lib/legal-data'

export const metadata: Metadata = {
  title: 'Юридические документы — Pulse Messenger',
  description:
    'Пользовательское соглашение, Политика конфиденциальности и Согласие на обработку персональных данных Pulse.',
}

export default function LegalIndexPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <span aria-hidden>←</span> На главную
        </Link>
        <h1 className="mt-6 text-balance text-3xl font-bold">Юридические документы</h1>
        <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
          Документы, регулирующие использование мессенджера {SERVICE.name} и обработку персональных
          данных в соответствии с 152-ФЗ и требованиями Роскомнадзора 2026 года.
        </p>

        <ul className="mt-8 flex flex-col gap-4">
          {LEGAL_DOCS.map((doc) => (
            <li key={doc.slug}>
              <Link
                href={`/legal/${doc.slug}`}
                className="block rounded-xl border border-border p-5 transition-colors hover:bg-secondary/60"
              >
                <p className="font-semibold">{doc.title}</p>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {doc.description}
                </p>
              </Link>
            </li>
          ))}
        </ul>

        <p className="mt-8 text-xs text-muted-foreground">
          Действующая редакция от {LAST_UPDATED}. Документы размещены в открытом доступе согласно
          ч. 2 ст. 18.1 Федерального закона № 152-ФЗ.
        </p>
      </div>
    </div>
  )
}
