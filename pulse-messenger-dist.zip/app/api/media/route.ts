import { get } from '@vercel/blob'
import { NextResponse } from 'next/server'
import { requireUserId } from '@/lib/auth/require-user'

export async function GET(request: Request) {
  try {
    await requireUserId()
    const pathname = new URL(request.url).searchParams.get('pathname')
    if (!pathname?.startsWith('pulse/')) return NextResponse.json({ error: 'Некорректный путь' }, { status: 400 })
    const result = await get(pathname, {
      access: 'private',
      ifNoneMatch: request.headers.get('if-none-match') ?? undefined,
    })
    if (!result) return new NextResponse('Not found', { status: 404 })
    if (result.statusCode === 304) return new NextResponse(null, { status: 304, headers: { ETag: result.blob.etag, 'Cache-Control': 'private, no-cache' } })
    return new NextResponse(result.stream, { headers: { 'Content-Type': result.blob.contentType, ETag: result.blob.etag, 'Cache-Control': 'private, no-cache', 'Content-Disposition': 'inline' } })
  } catch {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
}
